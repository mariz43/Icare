package com.example.user.coding.loging_system;

import android.app.Application;
import android.content.Intent;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class home extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        FirebaseAuth fbouth=FirebaseAuth.getInstance();
        FirebaseUser fbuser=fbouth.getCurrentUser();
        if(fbuser != null){

            startActivity(new Intent(home.this,NevigationActivity.class));



        }
    }
}

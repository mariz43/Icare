package com.example.user.coding.loging_system;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.user.coding.R;

public class Doctorlist extends AppCompatActivity {
    private ListView listView;  private static final int REQUEST_CALL = 1;
    private  String [] items={" 01711323648"," 01789779955"," 01819131008"};
    private  String [] itemsw={" DR.SAYED MOHAMMAD ELIAS ,Orthopaedic,Khulna medical College & Hospital Khulna"," Dr Iftekhar Md Munir , Ophthalmologist (Eye Specialist),Bangladesh Eye Hospital, Shantinagar, Dhaka.","Dr Md Mozammel Haque,Physiotherapist / pain & paralysist,  Advanced Hospital,Al-Razi Islamia Hospital and American Int Hospital"};



    @Override
    public void onBackPressed() {
       Intent intent=new Intent(Doctorlist.this,NevigationActivity.class);startActivity(intent);  super.onBackPressed();
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctorlist);
        Customadapter customadapter=new Customadapter(Doctorlist.this,items,itemsw);
        listView= (ListView) findViewById(R.id.listv);
        listView.setAdapter(customadapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                String itr=(String) listView.getItemAtPosition(position);






                if (itr.trim().length() > 0) {

                    if (ContextCompat.checkSelfPermission(Doctorlist.this,
                            Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(Doctorlist.this,
                                new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
                    } else {
                        String dial = "tel:" + itr;
                        startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
                    }
                }







            }
        });
    }
}


package com.example.user.coding.loging_system;

public class posteddiet {
    String dshift;
    String dtime;
    String ddscrip;

    public posteddiet(){

    }


    public posteddiet(String dshift, String dtime, String ddscrip) {
        this.dshift = dshift;
        this.dtime = dtime;
        this.ddscrip = ddscrip;
    }

    public String getDshift() {
        return dshift;
    }

    public void setDshift(String dshift) {
        this.dshift = dshift;
    }

    public String getDtime() {
        return dtime;
    }

    public void setDtime(String dtime) {
        this.dtime = dtime;
    }

    public String getDdscrip() {
        return ddscrip;
    }

    public void setDdscrip(String ddscrip) {
        this.ddscrip = ddscrip;
    }
}

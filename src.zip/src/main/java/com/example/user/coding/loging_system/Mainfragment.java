package com.example.user.coding.loging_system;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.AlertDialogLayout;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.user.coding.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


public class Mainfragment extends Fragment {


    public  Mainfragment() {

    }
    private DatabaseReference mdatabasse;
    private RecyclerView mbloglist;
FirebaseRecyclerAdapter<posteddiet, Mainfragment.mainfragviewholder> firebaseRecyclerAdapter;
    private FirebaseAuth firebaseAut;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_mainfragment, container, false);
        firebaseAut= FirebaseAuth.getInstance();
        mdatabasse= FirebaseDatabase.getInstance().getReference().child(firebaseAut.getUid()).child("diet");
        mbloglist=(RecyclerView) rootView.findViewById(R.id.fraglist);

        mbloglist.setHasFixedSize(true);
        mbloglist.setLayoutManager(new LinearLayoutManager(getActivity()));




        // Inflate the layout for this fragment
        return rootView;
    }




    @Override
    public void onStart() {
        super.onStart();
       firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<posteddiet, Mainfragment.mainfragviewholder>(
                posteddiet.class,R.layout.dietrow, Mainfragment.mainfragviewholder.class,mdatabasse
        ) {



            @Override
            protected void populateViewHolder(Mainfragment.mainfragviewholder viewHolder, posteddiet model, final int position) {

                viewHolder.setdshift(model.getDshift());
                viewHolder.setddscrip(model.getDdscrip());
                viewHolder.setdtime(model.getDtime());
viewHolder.itemView.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(getActivity(), Alarmnot.class);
        startActivity(intent);
    }
});




viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
              @Override
              public boolean onLongClick(View v) {
                  AlertDialog.Builder builder=new AlertDialog.Builder(getContext());
                  builder.setMessage("Delete entry?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
int Selecteditems=position;
                          firebaseRecyclerAdapter.getRef(Selecteditems).removeValue();
                          firebaseRecyclerAdapter.notifyItemRemoved(Selecteditems);
                          mbloglist.invalidate();
                          onStart();
                      }
                  }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                      @Override
                      public void onClick(DialogInterface dialog, int which) {
                          dialog.cancel();
                      }
                  });
                  AlertDialog dialog=builder.create();
                  dialog.setTitle("Confirm");
                  dialog.show();
                  return false;
              }
          });




            }
        };




        mbloglist.setAdapter(firebaseRecyclerAdapter);
    }








    public static class mainfragviewholder extends RecyclerView.ViewHolder {

        View mview;

        public mainfragviewholder(View itemView) {
            super(itemView);
            mview = itemView;

        }

        public void setdshift(String dshift) {
            TextView posttitle = (TextView) mview.findViewById(R.id.dietshifts);
            posttitle.setText(dshift);


        }

        public void setddscrip(String description) {
            TextView postdescrip = (TextView) mview.findViewById(R.id.dietdescrips);
            postdescrip.setText(description);


        }

        public void setdtime(String dtime) {
            TextView dieetime = (TextView) mview.findViewById(R.id.diettimes);
            dieetime.setText(dtime);


        }


    }


}


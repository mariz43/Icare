package com.example.user.coding.loging_system;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.user.coding.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;

public class relatives extends AppCompatActivity {
    private FirebaseAuth firebaseAut;
    private DatabaseReference mdatabase;
    private ArrayList<String> mphp=new ArrayList<>();
    private EditText editText; private Button button;private ListView listView;

    @Override
    public void onBackPressed() {
       Intent intent=new Intent(relatives.this,NevigationActivity.class);startActivity(intent); super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_relatives);
        firebaseAut= FirebaseAuth.getInstance();
        mdatabase= FirebaseDatabase.getInstance().getReference().child(firebaseAut.getUid()).child("relatives");
        editText=(EditText) findViewById(R.id.textc);
        button=(Button) findViewById(R.id.buttc);
        listView=(ListView) findViewById(R.id.listc);
        final ArrayAdapter<String> arrayAdapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,mphp);
        listView.setAdapter(arrayAdapter);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String post= editText.getText().toString().trim();

                if (TextUtils.isEmpty(post)){

                    Toast.makeText(relatives.this,"Fields is Empty", Toast.LENGTH_SHORT).show();
                }
                else{


                HashMap<String,String> hashMap= new HashMap<String, String>();
                hashMap.put("relat",post);
                mdatabase.push().setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(relatives.this,"Posted", Toast.LENGTH_SHORT).show();
                            editText.setText("");
                        }
                    }
                });



            }
            }
        });



        mdatabase.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String value=dataSnapshot.child("relat").getValue(String.class);

                mphp.add(value.toString());
                arrayAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                arrayAdapter.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {



            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        int itempos=position;
        String itemvalue=(String) listView.getItemAtPosition(position);
        Intent intent =new Intent(relatives.this,reldetail.class);
        intent.putExtra("rels",itemvalue);
        startActivity(intent);
    }
});







listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, final long id) {



        AlertDialog.Builder builder=new AlertDialog.Builder(relatives.this);
        builder.setMessage("Delete entry?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                int Selecteditems=position;
                String itemvaluse=(String) listView.getItemAtPosition(position);





                Query applesQuery = mdatabase.orderByChild("relat").equalTo(itemvaluse);

                applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        for (DataSnapshot appleSnapshot: dataSnapshot.getChildren()) {
                            appleSnapshot.getRef().removeValue();
                            Intent i=new Intent(relatives.this,relatives.class);
                            startActivity(i);


                        }
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });

            }
        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog dialog=builder.create();
        dialog.setTitle("Confirm");
        dialog.show();



        return true;
    }
});
    }
}


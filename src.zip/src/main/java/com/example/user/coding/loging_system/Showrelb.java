package com.example.user.coding.loging_system;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.user.coding.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.squareup.picasso.Picasso;

public class Showrelb extends AppCompatActivity {
    public String strtses;
    private DatabaseReference mdatabasse;
    private RecyclerView mbloglist;
    FirebaseRecyclerAdapter<posteditem,Blog.Blogviewholder> firebaseRecyclerAdapter;
    private FirebaseAuth firebaseAut;
    public Showrelb() {
    }



    @Override
    public void onBackPressed() {
     Intent intent=new Intent(Showrelb.this,relatives.class);startActivity(intent); super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_showrelb);

        Intent intent=getIntent();
        strtses= intent.getStringExtra("rel");

        firebaseAut= FirebaseAuth.getInstance();
        mdatabasse= FirebaseDatabase.getInstance().getReference().child(firebaseAut.getUid()).child(strtses);
        mbloglist=(RecyclerView) findViewById(R.id.blogl);
        mbloglist.setHasFixedSize(true);
        mbloglist.setLayoutManager(new LinearLayoutManager(this));



    }


    // Inflate the layout for this fragment






    @Override
    protected void onStart() {
        super.onStart();
     firebaseRecyclerAdapter=new FirebaseRecyclerAdapter<posteditem, Blog.Blogviewholder>(
                posteditem.class,R.layout.blogrow,Blog.Blogviewholder.class,mdatabasse
        ) {



            @Override
            protected void populateViewHolder(Blog.Blogviewholder viewHolder, posteditem model, final int position) {

                viewHolder.settitle(model.getTitle());
                viewHolder.setdescription(model.getDescription());
                viewHolder.setimage(getApplicationContext(),model.getImage());


                viewHolder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        AlertDialog.Builder builder=new AlertDialog.Builder(Showrelb.this);
                        builder.setMessage("Delete entry?").setCancelable(false).setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                int Selecteditems=position;
                                firebaseRecyclerAdapter.getRef(Selecteditems).removeValue();
                                firebaseRecyclerAdapter.notifyItemRemoved(Selecteditems);
                                mbloglist.invalidate();
                                onStart();
                            }
                        }).setNegativeButton("No", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.cancel();
                            }
                        });
                        AlertDialog dialog=builder.create();
                        dialog.setTitle("Confirm");
                        dialog.show();
                        return false;
                    }
                });

            }
        };
        mbloglist.setAdapter(firebaseRecyclerAdapter);
    }








    public static class Blogviewholder extends RecyclerView.ViewHolder{

        View mview;
        public Blogviewholder(View itemView) {
            super(itemView);
            mview=itemView;

        }


        public void settitle(String title){
            TextView posttitle=(TextView) mview.findViewById(R.id.titleposted);
            posttitle.setText(title);


        }

        public void setdescription(String description){
            TextView postdescription=(TextView) mview.findViewById(R.id.descposted);
            postdescription.setText(description);


        }

        public void setimage(Context ctx, String image){
            ImageView post_image=(ImageView) mview.findViewById(R.id.imageposted);


            //  Picasso.with(ctx).load(image).into(post_image);
            Picasso.get().load(image).into(post_image);

        }


    }}


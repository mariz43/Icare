package com.example.user.coding.loging_system;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import com.example.user.coding.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

//shemulhasanicare@gmail.com         pass: shemul43hasani
public class MainActivity extends AppCompatActivity {
    private ProgressDialog progressDialog;
    private FirebaseAuth firebaseAut;private FirebaseAuth.AuthStateListener authStateListener;  EditText Email;  EditText Password;

    @Override
    public void onBackPressed() {
        finishAffinity();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        progressDialog=new ProgressDialog(this);
        firebaseAut=FirebaseAuth.getInstance();
        Button SignIN = (Button) findViewById(R.id.SignIn);
        Button Register = (Button) findViewById(R.id.Register);
       Email = (EditText) findViewById(R.id.EmailPhone);
        Password = (EditText) findViewById(R.id.PassWord);








       authStateListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser()!=null){
                    startActivity(new Intent(MainActivity.this,NevigationActivity.class));}

                }
            }
        ;


        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, signup_Activity.class);
                startActivity(myIntent);



            }
        });




        SignIN.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startsignin();

            }
        });









    }









    @Override
    protected void onStart() {
        super.onStart();
        firebaseAut.addAuthStateListener(authStateListener);
    }




    private void startsignin(){
        String email=Email.getText().toString();
        String password=Password.getText().toString();
        if (TextUtils.isEmpty(email)|| TextUtils.isEmpty(password)){

            Toast.makeText(MainActivity.this,"Fields Are Empty", Toast.LENGTH_SHORT).show();
        }
        else{  progressDialog.setMessage("Secure Internet Connection Needed Please Wait...");

            progressDialog.show();
            firebaseAut.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){ progressDialog.dismiss();
                        startActivity(new Intent(MainActivity.this,NevigationActivity.class));
                    }
                }
            });}
    }







  /*  boolean twice;

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            // super.onBackPressed();
            Toast.makeText(MainActivity.this,"Press again to exit",Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    twice=false;
                }
            },3000);
            twice=true;


            if (twice==true){

                Intent intent=new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_HOME);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(intent);
                finish();System.exit(0);





            }



        }*/




    }








package com.example.user.coding.loging_system;

import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;

import android.support.design.widget.NavigationView;

import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import android.widget.ImageView;
import android.widget.Toast;

import com.example.user.coding.R;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;


public class NevigationActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private FirebaseAuth firebaseAut;

    private FirebaseAuth.AuthStateListener authStateListener;
    ImageView imageView;
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private static final int GALLERY_PICK = 1;

    // Storage Firebase
    private StorageReference mImageStorage;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nevigation);


        Mainfragment fragment = new Mainfragment();
        android.support.v4.app.FragmentTransaction fragmentTransaction =
                getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.fragment_container, fragment);
        fragmentTransaction.commit();




        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);

        imageView= (ImageView) findViewById(R.id.imageViewoo);


        mImageStorage = FirebaseStorage.getInstance().getReference();

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();

        String current_uid = mCurrentUser.getUid();

        mUserDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child(current_uid);
        mUserDatabase.keepSynced(true);
        mUserDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        firebaseAut=FirebaseAuth.getInstance();
        authStateListener=new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                if (firebaseAuth.getCurrentUser()==null){


                    startActivity(new Intent(NevigationActivity.this,MainActivity.class));


                }
            }
        };


        setSupportActionBar(toolbar);



        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);






    }

    public void updateProfile(View view){

    }
boolean twice;
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
           // super.onBackPressed();
            Toast.makeText(NevigationActivity.this,"Press again to exit",Toast.LENGTH_SHORT).show();
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
twice=false;
                }
            },3000);
            twice=true;


      if (twice==true){

Intent intent=new Intent(Intent.ACTION_MAIN);
intent.addCategory(Intent.CATEGORY_HOME);
intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
startActivity(intent);
finish();System.exit(0);





      }



       }




    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.nevigation, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            logout();
        }


        return super.onOptionsItemSelected(item);
    }





    private void logout() {
        firebaseAut.getInstance().signOut();Intent ii= new Intent(NevigationActivity.this,MainActivity.class) ;

ii.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
ii.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(ii);
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_diet) {
            // Handle the camera action
            Intent myIntent = new Intent(NevigationActivity.this,dietchart.class);
            startActivity(myIntent);
        }

        if (id == R.id.nav_android) {
            // Handle the camera action
            Intent myIntent = new Intent(NevigationActivity.this,Addblog.class);
            startActivity(myIntent);
        } else if (id == R.id.nav_php) {
            Intent myIntent = new Intent(NevigationActivity.this,Blog.class);
            startActivity(myIntent);

        }

        else if (id == R.id.nav_hospitalsnear) {
            String uri = "geo:"+"?q=hospitals+near+me";
            startActivity(new Intent(android.content.Intent.ACTION_VIEW, Uri.parse(uri)));
        }

        else if (id == R.id.nav_html) {
            Intent myIntent = new Intent(NevigationActivity.this,relatives.class);
            startActivity(myIntent);

        } else if (id == R.id.nav_java) {
            Intent myIntent = new Intent(NevigationActivity.this,Doctorlist.class);
            startActivity(myIntent);

        }
        else if (id == R.id.nav_CPlus) {
            Intent myIntent = new Intent(NevigationActivity.this,Ambulenceservices.class);
            startActivity(myIntent);

        }



        else if (id == R.id.nav_share) {
            Intent myIntent = new Intent(NevigationActivity.this,Aboutus.class);
            startActivity(myIntent);

        }


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}

package com.example.user.coding.loging_system;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.user.coding.R;

public class Customadapter extends ArrayAdapter<String> {
    private final Context context;
    private  final String [] items;
    private  final String [] itemsw;


    public Customadapter(Context context, String[] items, String[]itemsw) {
        super(context, R.layout.customlayout,items);
        this.context = context;
        this.items = items;
        this.itemsw =itemsw;
    }


    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater=(LayoutInflater)getContext().getSystemService(context.LAYOUT_INFLATER_SERVICE);
        View rowview=inflater.inflate(R.layout.customlayout,null,true);

        TextView textView=(TextView) rowview.findViewById(R.id.text32);
        TextView textViews=(TextView) rowview.findViewById(R.id.text);
        textView.setText(items[position]);


        textViews.setText(itemsw[position]);

        return rowview;


    }
}

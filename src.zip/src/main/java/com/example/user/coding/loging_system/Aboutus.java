package com.example.user.coding.loging_system;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.user.coding.R;

public class Aboutus extends AppCompatActivity {
    @Override
    public void onBackPressed() {
       Intent intent=new Intent(Aboutus.this,NevigationActivity.class);startActivity(intent); super.onBackPressed();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aboutus);
    }
}

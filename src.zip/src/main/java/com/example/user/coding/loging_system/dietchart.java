package com.example.user.coding.loging_system;

import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.user.coding.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Calendar;

public class dietchart extends AppCompatActivity {
    private FirebaseAuth firebaseAut;
    private FirebaseAuth.AuthStateListener authStateListener;
    private DatabaseReference mdatabbase;
private Spinner spinners;



  private  EditText chooseTime;
    private TimePickerDialog timePickerDialog;
    private Calendar calendar;
    private int currentHour;
    private int currentMinute;
   private  String amPm;


    String ase;





    private EditText mPostdesc;
    private Uri mimageUri=null;
    private Button mSubmitBtn;
private String dietselecter;
    private ProgressDialog mmprogress;




    @Override
    public void onBackPressed() {
        Intent intent=new Intent(dietchart.this,NevigationActivity.class);startActivity(intent); super.onBackPressed();
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dietchart);



        firebaseAut= FirebaseAuth.getInstance();
        mdatabbase= FirebaseDatabase.getInstance().getReference().child(firebaseAut.getUid()).child("diet");






        mPostdesc = (EditText) findViewById(R.id.dietdesc);
        spinners=(Spinner)findViewById(R.id.spinner);

        mSubmitBtn = (Button) findViewById(R.id.submitdiet);
        mmprogress=new ProgressDialog(this);










        chooseTime = findViewById(R.id.etChooseTime);
        chooseTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calendar = Calendar.getInstance();
                currentHour = calendar.get(Calendar.HOUR_OF_DAY);
                currentMinute = calendar.get(Calendar.MINUTE);

                timePickerDialog = new TimePickerDialog(dietchart.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minutes) {
                        if (hourOfDay > 12) {
                            hourOfDay -= 12;
                            amPm = "PM";
                        } else if (hourOfDay == 0) {
                            hourOfDay += 12;
                            amPm = "AM";
                        } else if (hourOfDay == 12){
                            amPm = "PM";
                        }else{
                            amPm = "AM";
                        }
                        chooseTime.setText(String.format("%02d:%02d", hourOfDay, minutes) + amPm);
                    }
                }, currentHour, currentMinute, false);

                timePickerDialog.show();


            }
        });















        final String []dietshift={"Breakfast","Lunch","Dinner","Medicines"};
        ArrayAdapter<String> arradpt=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,dietshift);
        spinners.setAdapter(arradpt);

        spinners.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                switch (position){
                case 0 : dietselecter="Breakfast";break;
                    case 1 :dietselecter="Lunch";break;
                    case 2 :dietselecter="Dinner";break;
                    case 3 : dietselecter= "Medicines";break;

                }ase=dietselecter.trim();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
















        mSubmitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startposting();
            }
        });
    }























    private void startposting() {mmprogress.setMessage("Posting...");


        final String descvalue=mPostdesc.getText().toString().trim();


        final  String timer=chooseTime.getText().toString().trim();
            mmprogress.show();



                    DatabaseReference newpost=mdatabbase.push();

                    newpost.child("ddscrip").setValue(descvalue);
                    newpost.child("dshift").setValue(ase);
newpost.child("dtime").setValue(timer);


                    mmprogress.dismiss();
                    startActivity(new Intent(dietchart.this,NevigationActivity.class));
                }


        }




